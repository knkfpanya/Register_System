(function($) {

	"use strict";

	$(".toggle-password").click(function() {

  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});

})(jQuery);


$(document).ready(function() {
    login_form()
});

function login_form(){
  $.get("index.php/dashboard_c/login_form",
    function(data){
      $('#login_form').html(data);
    }
  );
}
$("body").on("click","#signin_form",function(){
    login_form();
});
$("body").on("click","#login_save",function(){
    $.each($("#SignInForm").find(".chkLoginEmpty"),function(){
        if($(this).val()==""){
            $(this).addClass("is-invalid");
        }
        else{
            $(this).removeClass("is-invalid");
        }
    });
    if($("#SignInForm").find(".is-invalid").length==0){
        $.ajax({
            type: 'GET',
            dataType: 'json',
            url: 'index.php/dashboard_c/login_save',
            data:{UserI_Username:$("#usernameLogin").val(),UserI_Password:$("#passwordLogin").val()}
        })
        .done(function(response){
            if(response.sendback=="wrong"){
                $("#errorSignIN").html("* Username or Password were wrong.")
            }
            else{
                $.confirm({
                    icon: 'fa fa-check-circle',
                    closeIcon: false,
                    columnClass: 'col-md-8',
                    type: 'green',
                    backgroundDismiss: false,
                    title: 'Success',
                    content: "<p class='pl-5 mt-3'>Going to sign in.</p>",
                    autoClose: 'submitAction|5000',
                    buttons: {
                        submitAction: {
                            text: 'Close',
                            btnClass: 'btn-md btn-red btn-block pr-5 pl-5',
                            action: function () {
                                location.reload();
                            }
                        }
                    }
                });
            }
            
        })
        .fail(function(data){
            console.log(data.responseText);
        });
    }


});



function signup_form(){
  $.get("index.php/dashboard_c/signup_form",
    function(data){
      $('#login_form').html(data);
    }
  );
}
$("body").on("click","#signup_form",function(){
  signup_form();
});
function chkEmpty(){
    countEmpty=0;
    $.each($("#login_form").find(".chkEmpty"),function(){
        if($(this).val()==""){
            countEmpty++;
        }
    });
    if($("#password").hasClass('.chkEmpty')){
        if($("#password").val().length<6){
            countEmpty++;
        }
    }
    
    return countEmpty;
}
$("body").on("change",".chkPassword",function(){
  let countChk=0;
  $.each($(".chkPassword"),function(){
    if($(this).val()==""){
      countChk++;
    }
  });

  if(countChk==0){
    if($("#password").val()==$("#confpassword").val()){
        $("#alertMsg").html("");
        $("#password").removeClass("is-invalid");
        $("#confpassword").removeClass("is-invalid");
        $("#error_matchpass").html("");
        if(chkEmpty()==0){
            $(".saveBtn").removeAttr("disabled");
        }
    }
    else{
        $("#alertMsg").html();
        $("#password").addClass("is-invalid");
        $("#confpassword").addClass("is-invalid");
        $("#error_matchpass").html("* Password do not match.");
        $(".saveBtn").attr("disabled",true);
    }
  }
  
});
$("body").on("change",".chkEmpty",function(){
    if(chkEmpty()==0){
        $(".saveBtn").removeAttr("disabled");
    }else{
        $(".saveBtn").attr("disabled",true);
    }
});
$("body").on("keypress",".checktext",function(event){
    var list=[48,49,50,51,52,53,54,55,56,57,95,
              65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,
              97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,
    ];
    if(jQuery.inArray(event.keyCode,list)==-1){
        return false;
    }
    
});
$("body").on("change","#username",function(){
    $.ajax({
        url: 'index.php/dashboard_c/chkUsername',
        type: 'GET',
        dataType: 'json',
        data: {UserI_Username:$(this).val()}
    })
    .done(function(data) {
        if(data=="exist"){
            $("#error_username").html("* This username has already exist.");
            $("#username").addClass("is-invalid")
            $(".saveBtn").attr("disabled",true);
        }
        else{
            $("#error_username").html("");
            $("#username").removeClass("is-invalid")
            if(chkEmpty()==0){
                $(".saveBtn").removeAttr("disabled");
            }
        }
    })
    .fail(function() {
        console.log("error");
    });
});
$("body").on("change","#password",function(){
    if($(this).val().length<6){
        $(".saveBtn").attr("disabled",true);
        $("#password").addClass("is-invalid");
        $("#error_pass").html("Password must more than 6 character.");
    }
    else{
        $(".saveBtn").removeAttr("disabled");
        $("#password").removeClass("is-invalid");
        $("#error_pass").html("");
    }
});
$("body").on("change",".custom-file-input", function() {
    var fileName = $(this).val().split("\\").pop();
    $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});
$("body").on("click","#sigup_save",function(){
    if(chkEmpty()==0){
        let dataSave=[$("#username").val(),$("#password").val(),UserI_FName=$("#firstname").val(),$("#surname").val()];
        $.confirm({
            icon: 'fas fa-info-circle mr-2',
            // theme: 'supervan',
            columnClass: 'col-md-8',
            animation: 'scale',
            type: 'info',
            draggable: false,
            closeIcon: false,

            title:"Are you sure?",
            content:"<div class='pl-5 pr-5'>Please make your data sure that you want to sign up.    </div>",
            buttons: {
                agree:{
                    text: "<i class='far fa-check-circle mr-2'></i>Submit",
                    btnClass: 'btn-green pr-5 pl-5 mr-2',
                    action: function() {
                        event.preventDefault();
                        var dataFile = new FormData();
                        dataFile.append("UserI_Image",$('#UserI_Image')[0].files[0]);
                        dataFile.append("saveData",dataSave);
                        $.ajax({
                            type: 'POST',
                            enctype: 'multipart/form-data',
                            url: 'index.php/dashboard_c/sigup_save',
                            processData: false,
      		                contentType: false,
                            cache: false,
                            dataType: 'json',
                            timeout: 600000,
                            data:dataFile
                        })
                        .done(function(response){
                            console.log(response)
                            $.confirm({
                                icon: 'fa fa-check-circle',
                                closeIcon: false,
                                columnClass: 'col-md-8',
                                type: 'green',
                                backgroundDismiss: false,



                                title: 'Success',
                                content: "<p class='pl-5 mt-3'>Sign Up Complete</p>",
                                autoClose: 'submitAction|30000',
                                buttons: {
                                    submitAction: {
                                        text: 'Close',
                                        btnClass: 'btn-md btn-red btn-block pr-5 pl-5',
                                        action: function () {
                                            login_form();
                                        }
                                    }
                                }
                            });
                        })
                        .fail(function(data){
                            console.log(data.responseText);
                        });
                    }
                },
                cancel:{
                    text: "<i class='far fa-times-circle mr-2'></i>Cancel",
                    btnClass: 'btn-red pr-5 pl-5 ml-2',
                },
            }
        });
    }
});

