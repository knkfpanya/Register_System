$(document).ready(function() {
    User_Field()
});

function User_Field(){
    $.get("index.php/dashboard_c/User_Field",
        function(data){
            $('#User_Field').html(data);
        }
    );
}
$("body").on("click","#BackUserField",function(){
    User_Field();
})

$("body").on("click","#EditBtn",function(){
    $.confirm({
        icon: 'fas fa-info-circle mr-2',
        columnClass: 'col-md-8',
        animation: 'scale',
        type: 'info',
        draggable: false,
        closeIcon: false,

        title:"Are you sure?",
        content:"<div class='pl-5 pr-5'>Please make your want to Edit your profile.</div>",
        buttons: {
            agree:{
                text: "<i class='far fa-check-circle mr-2'></i>Submit",
                btnClass: 'btn-green pr-5 pl-5 mr-2',
                action: function() {
                    $.get("index.php/dashboard_c/Edit_Field",
                        function(data){
                            $('#User_Field').html(data);
                        }
                    );
                }
            },
            cancel:{
                text: "<i class='far fa-times-circle mr-2'></i>Cancel",
                btnClass: 'btn-red pr-5 pl-5 ml-2',
            },
        }
    });
});



$("body").on("click","#SignOutBtn",function(){
    $.confirm({
        icon: 'fas fa-info-circle mr-2',
        // theme: 'supervan',
        columnClass: 'col-md-8',
        animation: 'scale',
        type: 'info',
        draggable: false,
        closeIcon: false,

        title:"Are you sure?",
        content:"<div class='pl-5 pr-5'>Please make your want to sign out.</div>",
        buttons: {
            agree:{
                text: "<i class='far fa-check-circle mr-2'></i>Submit",
                btnClass: 'btn-green pr-5 pl-5 mr-2',
                action: function() {
                    $.ajax({
                        type: 'GET',
                        url: 'index.php/dashboard_c/logout_run',
                    })
                    .done(function(){
                        location.reload();
                    })
                    .fail(function(data){
                        console.log(data.responseText);
                    });
                }
            },
            cancel:{
                text: "<i class='far fa-times-circle mr-2'></i>Cancel",
                btnClass: 'btn-red pr-5 pl-5 ml-2',
            },
        }
    });
    c
});


$("body").on("change",".editpassword",function(){
    let editpassword=$(this).val();
    let UserL_UserI_ID=$(this).attr("UserL_UserI_ID")
    $.ajax({
        url: 'index.php/dashboard_c/chkHistoryPassword',
        type: 'GET',
        dataType: 'json',
        data: {Password:editpassword,UserL_UserI_ID:UserL_UserI_ID}
    })
    .done(function(data) {
        console.log(data);
        if(data>0){
            $(".saveBtn").attr("disabled",true);
            $("#password").addClass("is-invalid");
            $("#error_pass").html("** Duplicate password 5 times.");
        }
        else{
            $(".saveBtn").removeAttr("disabled");
            $("#password").removeClass("is-invalid");
            $("#error_pass").html("");
        }
    })
    .fail(function() {
        console.log("error");
    });
});


$("body").on("click","#SaveEditBtn",function(){
    let username=$("#username").val();
    let password=$("#password").val();
    let firstname=$("#firstname").val();
    let surname=$("#surname").val();
    $.ajax({
        url: 'index.php/dashboard_c/SaveEditBtn',
        type: 'GET',
        dataType: 'json',
        data: {UserI_ID:$(this).val(),username:username,password:password,firstname:firstname,surname:surname}
    })
    .done(function(data){
        $.confirm({
            icon: 'fa fa-check-circle',
            closeIcon: false,
            columnClass: 'col-md-8',
            type: 'green',
            backgroundDismiss: false,
            title: 'Success',
            content: "<p class='pl-5 mt-3'>Update Completed</p>",
            autoClose: 'submitAction|5000',
            buttons: {
                submitAction: {
                    text: 'Close',
                    btnClass: 'btn-md btn-red btn-block pr-5 pl-5',
                    action: function () {
                        User_Field()
                    }
                }
            }
        });
    })
    .fail(function() {
        console.log("error");
    });

});