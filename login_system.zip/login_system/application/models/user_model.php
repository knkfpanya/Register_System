<?php
    class user_model extends CI_Model{
        public function chkUsername($userI_Username){
            $this->db->select("UserI_ID");
            $this->db->from("list_user_info");
            $this->db->where("UserI_Status",1);
            $this->db->where("UserI_Username",$userI_Username);
            return $this->db->get()->result_array();
        }
        public function getUsername($UserI_ID){
            $this->db->select("*");
            $this->db->from("list_user_info");
            $this->db->where("UserI_Status",1);
            $this->db->where("UserI_ID",$UserI_ID);
            return $this->db->get()->result_array();
        }

        
    }

?>