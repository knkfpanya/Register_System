<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	class dashboard_c extends CI_Controller {
		public function index(){
			if(!isset($_SESSION['system_login_id'])){
				$this->load->view('pages/header');
				$this->load->view('pages/login_form');
				$this->load->view('pages/footer');
			}
			else{
				$this->load->view('pages/header');
				$this->load->view('pages/dashboard');
				$this->load->view('pages/footer');
			}
		}
		public function login_form(){
			echo "<div class='d-flex'>";
				echo "<div class='w-100'>";
					echo "<h3 class='mb-2'>Sign In</h3>";
				echo "</div>";
			echo "</div>";

			echo "<div id='SignInForm'>";
				echo "<div class='form-group mt-3'>";
					echo "<input id='usernameLogin' type='text' class='form-control chkLoginEmpty' placeholder='Username' maxlength='12' required>";
				echo "</div>";
				echo "<div class='form-group'>";
					echo "<input id='passwordLogin' type='password' class='form-control chkLoginEmpty' placeholder='Password' minlength='6' maxlength='20' required>";
				echo "</div>";
				echo "<div class='form-group'>";
					echo "<text id='errorSignIN' class='text-danger'></text>";
				echo "</div>";
			echo "</div>";

			echo "<div class='form-group text-center'>";
				echo "<button id='login_save' type='button' class='btn btn-info btn-block px-3 mb-2'>Sign In</button>";
				echo "<button id='signup_form' type='button' class='btn btn-success w-50 md-6'>Sign Up</button>";
			echo "</div>";
		}
		public function login_save(){
			$this->db->select("UserI_ID");
			$this->db->from("list_user_info");
			$this->db->where("UserI_Status",1);
				$this->db->where("UserI_Username",$_GET['UserI_Username']);
				$this->db->where("UserI_Password",md5($_GET['UserI_Password']));
			$StqUser=$this->db->get()->result_array();

			if(count($StqUser)>0){
				$_SESSION['system_login_id']=$StqUser[0]['UserI_ID'];
				$data['sendback']='success';
			}
			else{
				$data['sendback']='wrong';
			}

			echo json_encode($data);
		}


		public function signup_form(){
			echo "<div class='d-flex'>";
				echo "<div class='w-100'>";
					echo "<h3 class='mb-2'>Sign Up</h3>";
				echo "</div>";
			echo "</div>";

			echo "<div id='SignUpForm'>";
				echo "<div class='form-group mt-3'>";
					echo "<input id='username' type='text' class='form-control chkEmpty checktext saveSignUp' placeholder='Username' maxlength='12' autocomplete='off' required>";
					echo "<text id='error_username' class='text-danger'></text>";
				echo "</div>";
				echo "<div class='form-group'>";
					echo "<input id='password' type='password' class='SignUpPassword form-control chkPassword chkEmpty saveSignUp' maxlength='100' placeholder='Password' autocomplete='off' required>";
					echo "<text id='error_pass' class='text-danger'></text>";
				echo "</div>";
				echo "<div class='form-group'>";
					echo "<input id='confpassword' type='password' class='form-control chkPassword' maxlength='100' placeholder='Confirm Password' autocomplete='off' required>";
					echo "<text id='error_matchpass' class='text-danger'></text>";
				echo "</div>";
				echo "<div class='form-group'>";
					echo "<input id='firstname' type='text' class='form-control checktext saveSignUp' placeholder='First Name' maxlength='255' autocomplete='off' required>";
				echo "</div>";
				echo "<div class='form-group'>";
					echo "<input id='surname' type='text' class='form-control checktext chkEmpty saveSignUp' placeholder='Surname' maxlength='255' autocomplete='off' required>";
				echo "</div>";
				echo "<div class='form-group'>";
					echo "<div class='custom-file mb-3'>";
						echo "<input type='file' class='custom-file-input chkEmpty' id='UserI_Image' name='filename' accept='image/*'>";
						echo "<label class='custom-file-label' for='customFile'>Choose file</label>";
			  		echo "</div>";
				echo "</div>";
			echo "</div>";

			echo "<div class='form-group text-center'>";
				echo "<button id='sigup_save' type='button' class='btn btn-success saveBtn btn-block px-3 mb-2' disabled>Sign Up</button>";
				echo "<button id='signin_form' type='button' class='btn btn-info w-50 md-6'>Sign In</button>";
			echo "</div>";
				
		}
		public function chkUsername(){
			$this->load->model('user_model');
			$StqChkUer=$this->user_model->chkUsername($_GET['UserI_Username']);

			if(count($StqChkUer)>0){
				$return="exist";
			}
			else{
				$return="not exist";
			}
			echo json_encode($return);
		}
		public function sigup_save(){
			$dataSave=explode(",",$_POST['saveData']);

			$fileName=$dataSave[0];
			$file_name=explode(".",$_FILES['UserI_Image']['name']);
				$file_name_length=count($file_name);
			$config['upload_path'] = "/xampp/htdocs/login_system/assets/images/user_images";
			$config['allowed_types'] = 'gif|jpg|jpeg|png|GIF|JPG|JPEG|PNG';
			$config['max_size'] = 102400;
			$config['file_name'] = $fileName;
			$config['remove_spaces'] = false;

			$this->load->library('upload', $config);
			if(!$this->upload->do_upload('UserI_Image')){
				$data['error']=$this->upload->display_errors();
			}
			else{
				$data['upload_data']=$this->upload->data();
				$UserI_Images=$fileName.".".$file_name[($file_name_length-1)];
			}


			$this->db->trans_start();
				$this->db->set("UserI_UserName",$dataSave[0]);
				$this->db->set("UserI_Password",md5($dataSave[1]));
				$this->db->set("UserI_FName",$dataSave[2]);
				$this->db->set("UserI_SName",$dataSave[3]);
				$this->db->set("UserI_Image",$UserI_Images);
				$this->db->set("UserI_RegisDate",date("Y-m-d H:i:s"));
				$this->db->insert("list_user_info");
				$UserI_ID=$this->db->insert_id();
				// $feedback= $this->db->last_query();
				
				$this->db->set("UserL_UserI_ID",$UserI_ID);
				$this->db->set("UserL_Password",md5($dataSave[1]));
				$this->db->set("UserL_LogDate",date("Y-m-d H:i:s"));
				$this->db->insert("list_user_log");
			$this->db->trans_complete();

			echo json_encode('success');
		}


		// ================================
		public function User_Field(){
			$this->load->model('user_model');
			$StqUer=$this->user_model->getUsername($_SESSION['system_login_id'])[0];
			echo "<div class='card-body pb-5'>";
				echo "<div class='col-12 text-center'>";
					echo "<h5 class='card-title'>Hello ! ".$StqUer['UserI_FName']." ".$StqUer['UserI_SName']."</h5>";
					echo "<img id='userImage' src='".base_url("assets/images/user_images/".$StqUer['UserI_Image'])."' alt='User Images'>";
				echo "</div>";
			echo "</div>";
			echo "<div class='card-footer d-flex justify-content-between'>";
				echo "<button id='EditBtn' class='btn btn-success pr-4 pl-4'><i class='fas fa-edit mr-2'></i>Edit</button>";
				echo "<button id='SignOutBtn' class='btn btn-danger pr-4 pl-4'><i class='fas fa-sign-out-alt mr-2'></i>Sign out</button>";
			echo "</div>";
			
		}

		public function Edit_Field(){
			$this->load->model('user_model');
			$StqUer=$this->user_model->getUsername($_SESSION['system_login_id'])[0];
			echo "<div id='EditProfileField' class='card-body pb-5'>";
				echo "<h5 class='card-title mb-4'>Edit Your Profile</h5>";
				echo "<div id='login_form' class='col-12'>";
					echo "<div class='form-group mt-3'>";
						echo "<input id='username' type='text' class='form-control chkEmpty checktext saveEditProf' placeholder='Username' maxlength='12' autocomplete='off' value='".$StqUer['UserI_UserName']."'>";
						echo "<text id='error_username' class='text-danger'></text>";
					echo "</div>";
					echo "<div class='form-group'>";
						echo "<input id='password' type='password' class='form-control editpassword chkPassword saveEditProf' UserL_UserI_ID='".$StqUer['UserI_ID']."' maxlength='100' placeholder='Password' autocomplete='off'>";
						echo "<text id='error_pass' class='text-danger'></text>";
					echo "</div>";
					echo "<div class='form-group'>";
						echo "<input id='confpassword' type='password' class='form-control chkPassword' maxlength='100' placeholder='Confirm Password' autocomplete='off'>";
						echo "<text id='error_matchpass' class='text-danger'></text>";
					echo "</div>";
					echo "<div class='form-group'>";
						echo "<input id='firstname' type='text' class='form-control checktext chkEmpty saveEditProf' placeholder='First Name' maxlength='255' autocomplete='off'  value='".$StqUer['UserI_FName']."'>";
					echo "</div>";
					echo "<div class='form-group'>";
						echo "<input id='surname' type='text' class='form-control checktext chkEmpty saveEditProf' placeholder='Surname' maxlength='255' autocomplete='off'  value='".$StqUer['UserI_SName']."'>";
					echo "</div>";
				echo "</div>";
			echo "</div>";
			echo "<div class='card-footer d-flex justify-content-between'>";
				echo "<button id='BackUserField' class='btn btn-danger pr-4 pl-4'><i class='fas fa-arrow-left mr-2'></i>Back</button>";
				echo "<button id='SaveEditBtn' class='btn btn-success saveBtn pr-4 pl-4'  value='".$StqUer['UserI_ID']."'><i class='fas fa-save mr-2'></i>Save Update</button>";
			echo "</div>";
		}
		public function chkHistoryPassword(){
			$this->db->select("UserL_Password");
			$this->db->from("list_user_log");
			$this->db->where("UserL_UserI_ID",$_GET['UserL_UserI_ID']);
			$this->db->order_by("UserL_ID","DESC");
			$this->db->limit(5);
			$StqChkPass=$this->db->get()->result_array();
			$count=0;
			foreach ($StqChkPass as $key => $StqChkPass_result) {
				if($StqChkPass_result['UserL_Password']==md5($_GET['Password'])){
					$count++;
				}
			}
			echo json_encode($count);
		}


		public function SaveEditBtn(){
			$this->db->trans_start();
				$this->db->set("UserI_UserName",$_GET['username']);
				if(!empty($_GET['password'])){
					$this->db->set("UserI_Password",md5($_GET['password']));
				}
				$this->db->set("UserI_FName",$_GET['firstname']);
				$this->db->set("UserI_SName",$_GET['surname']);
				$this->db->where("UserI_ID",$_GET['UserI_ID']);
				$this->db->update("list_user_info");

				if(!empty($_GET['password'])){
					$this->db->set("UserL_UserI_ID",$_GET['UserI_ID']);
					$this->db->set("UserL_Password",md5($_GET['password']));
					$this->db->set("UserL_LogDate",date("Y-m-d H:i:s"));
					$this->db->insert("list_user_log");
				}
			$this->db->trans_complete();
			echo json_encode('success');
		}



		
		public function logout_run(){
			unset($_SESSION['system_login_id']);
		}

	}
?>
