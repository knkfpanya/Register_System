
        <section class="ftco-section mt-4 mb-4">
            <div class="container">
                <!-- <div class="row justify-content-center">
                    <div class="col-md-6 text-center mb-5">
                        <h2 class="heading-section">Login #05</h2>
                    </div>
                </div> -->
                <div class="row justify-content-center">
                    <div class="col-md-7 col-lg-5">
                        <div class="wrap">
                            <div class="img" style="background-image: url(<?=base_url("assets/images/bg.jpg")?>);"></div>
                            <div id='login_form' class="login-wrap p-4 p-md-4"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        

