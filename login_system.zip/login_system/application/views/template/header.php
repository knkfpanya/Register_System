<!DOCTYPE html>
<html lang="en">
 <head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta http-equiv="x-ua-compatible" content="ie=edge">
   <title>AMGT Examination Centre</title>
   <link rel='icon' href="<?= base_url('asset/images/icon.png') ?>" />
   <link rel="stylesheet" href="<?= base_url('asset/AdminLTE-3.0.2/plugins/fontawesome-free/css/all.min.css');?>">
   <link rel="stylesheet" href="<?= base_url('asset/AdminLTE-3.0.2/dist/css/adminlte.css');?>">
   <script src="<?= base_url('asset/AdminLTE-3.0.2/plugins/jquery/jquery.min.js');?>"></script>
   <script src="<?= base_url('asset/AdminLTE-3.0.2/plugins/bootstrap/js/bootstrap.bundle.min.js');?>"></script>
   <script src="<?= base_url('asset/AdminLTE-3.0.2/dist/js/adminlte.min.js');?>"></script>

   <link rel="stylesheet" href="<?= base_url('asset/AdminLTE-3.0.2/plugins/datatables-bs4/css/dataTables.bootstrap4.css');?>">
   <script src="<?= base_url('asset/AdminLTE-3.0.2/plugins/datatables/jquery.dataTables.js');?>"></script>
   <script src="<?= base_url('asset/AdminLTE-3.0.2/plugins/datatables-bs4/js/dataTables.bootstrap4.js');?>"></script>

   <link rel="stylesheet" href="<?= base_url('asset/AdminLTE-3.0.2/plugins/select2/css/select2.min.css');?>">
   <script src="<?= base_url('asset/AdminLTE-3.0.2/plugins/select2/js/select2.full.min.js');?>"></script>

   <link rel="stylesheet" href="<?= base_url('asset/sweetalert2/dist/sweetalert2.min.css');?>">
   <script src="<?= base_url('asset/sweetalert2/dist/sweetalert2.all.min.js');?>"></script>

   <script src="<?= base_url('asset/AdminLTE-3.0.2/plugins/moment/moment.min.js');?>"></script>
   <link rel="stylesheet" href="<?= base_url('asset/AdminLTE-3.0.2/plugins/daterangepicker/daterangepicker.css');?>">
   <script src="<?= base_url('asset/AdminLTE-3.0.2/plugins/daterangepicker/daterangepicker.js');?>"></script>

   <link rel="stylesheet" href="<?= base_url('asset/AdminLTE-3.0.2/dist/sweetalert/css/sweetalert2.min.css');?>">
   <script src="<?= base_url('asset/AdminLTE-3.0.2/dist/sweetalert/js/sweetalert2.min.js');?>"></script>

   <link rel="stylesheet" href="<?= base_url('asset/AdminLTE-3.0.2/plugins/icheck-bootstrap/icheck-bootstrap.min.css');?>">

   <link rel="stylesheet" href="<?= base_url('asset/AdminLTE-3.0.2/plugins/jquery-ui/jquery-ui.css');?>">
   <script src="<?= base_url('asset/AdminLTE-3.0.2/plugins/jquery-ui/jquery-ui.js');?>"></script>

   <link rel="stylesheet" href="<?= base_url('asset/myStyle.css');?>">
 </head>
 <body class="layout-top-nav">
   <div id='websiteBody' class="wrapper">
     <nav class="main-header navbar navbar-expand-md navbar-light navbar-white">
       <div class="container">
         <a href="http://172.18.106.7:88/amgt_exam" class="navbar-brand p-0">
           <!-- <span class="brand-text font-weight-light">Rin System</span> -->
           <span class="brand-text font-weight-light"><img src='<?= base_url("asset/images/icon.png")?>' width='40px'> Examination <b class='text-blue'>Centre</b></span>
         </a>
         <button class="navbar-toggler order-1" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
           <span class="navbar-toggler-icon"></span>
         </button>

         <div class="collapse navbar-collapse order-3" id="navbarCollapse">
           <ul class="navbar-nav">
             <li class="nav-item">
               <a href="http://172.18.106.7:88/amgt_exam" class="nav-link">Home</a>
             </li>
           </ul>

           <ul class="navbar-nav ml-auto">
             <li class="nav-item dropdown">
               <a class="nav-link" data-toggle="dropdown" href="#">
                 <i class="fas fa-user"></i>
               </a>
               <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right hide">
                 <span class="dropdown-header"><?=ucwords(strtolower($_SESSION['exam_login_name']));?></span>

                 <div class="dropdown-divider"></div>
                 <a href="#" class="dropdown-item">
                   <div class="ribbon-wrapper ribbon-lg">
                     <div class="ribbon bg-gray">
                       <text class='text-white'>Under <br /> Construction..</text>
                     </div>
                   </div><br />
                   <!-- <i class="fas fa-envelope mr-2"></i> -->
                   <span class="float-right text-muted text-sm" disabled></span>
                 </a>

                 <span class="dropdown-header"><br /><br /></span>
               </div>
             </li> &nbsp;&nbsp;&nbsp;&nbsp;


             <li class="nav-item p-1">
               <button type="button" id="btn_logout" class="btn btn-sm btn-danger" style="width: 80px;"> &nbsp; Log out &nbsp;</button>
             </li>
           </ul>
         </div>
       </div>
     </nav>
