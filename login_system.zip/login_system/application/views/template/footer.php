      <footer class="main-footer">
        <strong>Copyright © </strong><text class="text-blue">AGC Micro Glass(Thailand) Co.,Ltd.</text> All rights reserved.
      </footer>
    </div>

    <script>
      $(document).ready(function() {
        function GetIEVersion(){
          var sAgent = window.navigator.userAgent;
          var Idx = sAgent.indexOf("MSIE");
          // If IE, return version number.
          if (Idx > 0)
            return parseInt(sAgent.substring(Idx+ 5, sAgent.indexOf(".", Idx)));
          // If IE 11 then look for Updated user agent string.
          else if (!!navigator.userAgent.match(/Trident\/7\./))
            return 11;
          else
            return 0; //It is not IE
        }
        if (GetIEVersion() > 0){
          alert('กรุณาเปิดโปรแกรมผ่านเบราว์เซอร์ Google Chrome');
          window.open('','_self'); window.close();
        }
      });

      $('body').on('click', '#btn_logout', function(){
        logout_run();
      });
      function logout_run() {
        Swal.fire({
          title:'Are you sure?',
          text:"Please make sure that you want to log out!",
          icon:'question',
          showCancelButton:true,
          confirmButtonColor:'#b3b3b3',
          cancelButtonColor:'#dd3232',
          confirmButtonText:'Yes, do it.',
          cancelButtonText:'No, stay.'
        })
        .then((result) => {
          if (result.value) {
            $.ajax({
              url:'<?= site_url("dashboard_c/logout_run"); ?>',
              type:'POST',
              dataType:'json',
              data:{systemLogout:'systemLogout'}
            })
            .done(function(data){
              Swal.fire({
                title:'Log out !',
                html:"<br><i class='fas fa-spinner fa-spin'></i> &nbsp;&nbsp;System going to out..<br><br>",
                icon:'success',
                timer:2000,
                timerProgressBar:true,
                showConfirmButton:false,
              })
              .then((result) => {
                window.location.href="http://172.18.106.7:88/amgt_exam/";
              });
            })
            .fail(function() {
              console.log("error");
            });
          }
        })
      }
    </script>
  </body>
</html>
